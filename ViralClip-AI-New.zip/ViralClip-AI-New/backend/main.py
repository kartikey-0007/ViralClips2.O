import asyncio, json, os, re, shutil, subprocess, time, uuid
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

ROOT=Path(os.getenv('VIRALCLIP_DATA','/tmp/viralclip-ai'))
UPLOADS=ROOT/'uploads'; JOBS=ROOT/'jobs'; OUTPUTS=ROOT/'outputs'
for p in (UPLOADS,JOBS,OUTPUTS): p.mkdir(parents=True,exist_ok=True)
CHUNK_SIZE=8*1024*1024
MAX_BYTES=int(os.getenv('MAX_UPLOAD_BYTES',str(4*1024*1024*1024)))
ALLOWED={'.mp4','.mov','.webm','.mkv','.m4v','.avi'}
app=FastAPI(title='ViralClip AI API',version='1.0.0')
origins=os.getenv('CORS_ORIGINS','*').split(',')
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_credentials=False,allow_methods=['*'],allow_headers=['*'])

class StartUpload(BaseModel):
    filename:str
    size:int=Field(gt=0)
    content_type:str='application/octet-stream'
class JobRequest(BaseModel):
    upload_id:str
    clip_length:int=Field(default=30,ge=5,le=60)
    clip_count:int=Field(default=5,ge=1,le=10)
    aspect:str=Field(default='9:16')
    mode:str=Field(default='smart')
    manual_times:str=''
    auto_title:bool=True
    keep_audio:bool=True

jobs={}

def safe_name(name):
    name=Path(name).name
    stem=re.sub(r'[^A-Za-z0-9._-]+','_',Path(name).stem)[:80]
    ext=Path(name).suffix.lower()
    if ext not in ALLOWED: ext='.mp4'
    return stem+ext

def probe(path):
    cmd=['ffprobe','-v','error','-show_entries','format=duration,size','-of','json',str(path)]
    out=subprocess.check_output(cmd,text=True)
    d=json.loads(out)['format']; return float(d.get('duration') or 0),int(float(d.get('size') or 0))

def parse_ts(s):
    s=s.strip()
    if ':' in s:
        a=s.split(':')
        if len(a)==3:return int(a[0])*3600+int(a[1])*60+float(a[2])
        if len(a)==2:return int(a[0])*60+float(a[1])
    return float(s)

def smart_segments(duration,length,count):
    if duration<=length: return [(0,max(0,duration))]
    # Avoid only the very beginning/end. Spread candidates through the whole video.
    margin=min(60.0,duration*0.05)
    usable=max(0.0,duration-margin*2-length)
    if count==1: starts=[margin+usable/2]
    else: starts=[margin+(usable*i/(count-1)) for i in range(count)]
    # Add a tiny deterministic offset pattern so adjacent clips are not identical around boundaries.
    offsets=[0,-length*.12,length*.08,-length*.06,length*.04]
    return [(max(0,min(duration-length,st+offsets[i%len(offsets)])),0) for i,st in enumerate(starts)]

def even_segments(duration,length,count):
    if duration<=length:return [(0,duration)]
    if count==1:return [(0,length)]
    max_start=duration-length
    return [(max_start*i/(count-1),0) for i in range(count)]

def manual_segments(text,duration,length,count):
    out=[]
    for line in text.splitlines():
        if not line.strip():continue
        try:
            a,b=[parse_ts(x) for x in line.split(',',1)]
            if b<=a or a<0:continue
            if b-a>length:b=a+length
            if a<duration:out.append((a,min(b,duration)))
        except Exception:continue
    return out[:count]

def video_filter(aspect):
    if aspect=='9:16': return "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1"
    if aspect=='1:1': return "scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080,setsar=1"
    return "scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,setsar=1"

def process_job(job_id,req,src):
    job=jobs[job_id]
    outdir=OUTPUTS/job_id;outdir.mkdir(parents=True,exist_ok=True)
    try:
        duration,size=probe(src);job.update(progress=2,message=f'Video duration {duration/60:.1f} min. Analysing moments…')
        if req.mode=='manual':segs=manual_segments(req.manual_times,duration,req.clip_length,req.clip_count)
        elif req.mode=='even':segs=even_segments(duration,req.clip_length,req.clip_count)
        else:segs=smart_segments(duration,req.clip_length,req.clip_count)
        if not segs:raise RuntimeError('No valid clip timestamps were found.')
        outputs=[]
        for i,(start,_) in enumerate(segs,1):
            end=min(duration,start+req.clip_length);length=max(1,end-start)
            outfile=outdir/f'clip_{i:02d}.mp4'
            vf=video_filter(req.aspect)
            title=f'Viral Clip #{i}'
            cmd=['ffmpeg','-y','-ss',str(start),'-i',str(src),'-t',str(length),'-vf',vf]
            if req.keep_audio:cmd += ['-c:v','libx264','-preset','veryfast','-crf','23','-c:a','aac','-b:a','128k','-movflags','+faststart',str(outfile)]
            else:cmd += ['-an','-c:v','libx264','-preset','veryfast','-crf','23','-movflags','+faststart',str(outfile)]
            subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
            outputs.append({'title':title,'start':round(start,2),'end':round(end,2),'score':'Smart selection' if req.mode=='smart' else req.mode,'url':f'/api/files/{job_id}/{outfile.name}'})
            job['progress']=5+int(i/len(segs)*90);job['message']=f'Creating clip {i}/{len(segs)}…'
        job.update(status='done',progress=100,message='All clips created.',outputs=outputs)
    except Exception as e:
        job.update(status='error',progress=0,error=str(e),message='Processing failed.')
    finally:
        try:src.unlink(missing_ok=True)
        except:pass

@app.get('/')
def root():return {'name':'ViralClip AI API','status':'ok'}
@app.get('/health')
def health():return {'status':'ok','ffmpeg':shutil.which('ffmpeg') is not None,'ffprobe':shutil.which('ffprobe') is not None}
@app.post('/api/upload/start')
def upload_start(x:StartUpload):
    if x.size>MAX_BYTES:raise HTTPException(413,f'Max upload size is {MAX_BYTES/1024/1024/1024:.1f} GB')
    ext=Path(x.filename).suffix.lower()
    if ext not in ALLOWED:raise HTTPException(400,'Unsupported video format.')
    uid=uuid.uuid4().hex; p=UPLOADS/f'{uid}.part'; p.touch()
    (UPLOADS/f'{uid}.json').write_text(json.dumps({'filename':safe_name(x.filename),'size':x.size,'received':0}))
    return {'upload_id':uid,'chunk_size':CHUNK_SIZE}

@app.post('/api/upload/chunk/{uid}')
async def upload_chunk(uid:str,request:Request):
    meta_path=UPLOADS/f'{uid}.json';part=UPLOADS/f'{uid}.part'
    if not meta_path.exists() or not part.exists():raise HTTPException(404,'Upload session not found.')
    meta=json.loads(meta_path.read_text()); body=await request.body(); start=int(request.headers.get('content-range','bytes 0-0/1').split(' ')[1].split('-')[0])
    if start!=meta['received']:raise HTTPException(409,f'Expected byte {meta["received"]}.')
    if meta['received']+len(body)>meta['size']:raise HTTPException(413,'Upload exceeds declared size.')
    with part.open('ab') as f:f.write(body)
    meta['received']+=len(body);meta_path.write_text(json.dumps(meta))
    return {'received':meta['received'],'total':meta['size']}

@app.post('/api/upload/finish/{uid}')
def upload_finish(uid:str):
    meta_path=UPLOADS/f'{uid}.json';part=UPLOADS/f'{uid}.part'
    if not meta_path.exists():raise HTTPException(404,'Upload session not found.')
    meta=json.loads(meta_path.read_text())
    if meta['received']!=meta['size']:raise HTTPException(400,'Upload is incomplete.')
    final=UPLOADS/f'{uid}{Path(meta["filename"]).suffix.lower()}'
    part.replace(final);meta_path.unlink(missing_ok=True)
    return {'upload_id':uid,'filename':final.name}

@app.post('/api/jobs')
async def create_job(req:JobRequest):
    matches=list(UPLOADS.glob(req.upload_id+'*'))
    if not matches:raise HTTPException(404,'Uploaded video not found.')
    src=matches[0];jid=uuid.uuid4().hex;jobs[jid]={'status':'processing','progress':1,'message':'Queued…','outputs':[]}
    loop=asyncio.get_running_loop()
    loop.run_in_executor(None,process_job,jid,req,src)
    return {'job_id':jid}

@app.get('/api/jobs/{jid}')
def job_status(jid:str):
    if jid not in jobs:raise HTTPException(404,'Job not found.')
    return jobs[jid]

@app.get('/api/files/{jid}/{name}')
def get_file(jid:str,name:str):
    p=(OUTPUTS/jid/name).resolve();base=(OUTPUTS/jid).resolve()
    if base not in p.parents or not p.exists():raise HTTPException(404,'File not found.')
    return FileResponse(p,media_type='video/mp4',filename=p.name)
