# Android Chrome + GitHub mobile setup

## Part A — Create the repository
1. Open GitHub in Chrome and sign in.
2. Tap **+** → **New repository**.
3. Name it `ViralClip-AI`.
4. Choose **Public**.
5. Tap **Create repository**.

## Part B — Upload the project
If GitHub mobile does not show a folder upload button, use Chrome → **Desktop site**.

You need this structure:
```
ViralClip-AI/
  index.html
  style.css
  app.js
  backend/
    main.py
    requirements.txt
    Dockerfile
    .dockerignore
  README.md
```
The three files inside `frontend/` go in the repository root for the Pages site. The backend folder stays as `backend/`.

### Fastest method
1. Open the downloaded ZIP on your phone and extract it.
2. In the GitHub repo, tap **Add file** → **Upload files**.
3. Upload `index.html`, `style.css`, `app.js`, `README.md` and `.gitignore` to the root.
4. Create a folder named `backend` using **Add file → Create new file**, type `backend/main.py`, then paste/upload each backend file there.
5. Commit the changes.

## Part C — Publish the frontend
1. Repo → **Settings**.
2. **Pages**.
3. Under Build and deployment, choose **Deploy from a branch**.
4. Branch: `main`.
5. Folder: `/ (root)`.
6. Save.
7. Wait for the Pages deployment.

## Part D — Deploy the backend
Use Render for the first test because the repository already contains a Dockerfile.

1. Open Render and sign in with GitHub.
2. **New** → **Web Service**.
3. Connect `ViralClip-AI`.
4. Root Directory: `backend`.
5. Runtime/environment: Docker.
6. For the first test, Free is enough for a short video. Large 30–60 minute processing may require a paid instance/storage because free services have sleep and ephemeral-disk limits.
7. Create the service.
8. Copy the generated `https://...onrender.com` URL.

## Part E — Connect frontend to backend
Open `app.js` in GitHub and change only this line:
```js
const API = localStorage.getItem('viralclip_api') || 'YOUR_BACKEND_URL';
```
Replace `YOUR_BACKEND_URL` with your Render URL, for example:
```js
const API = localStorage.getItem('viralclip_api') || 'https://your-service.onrender.com';
```
Commit the change.

## Part F — Test in this exact order
1. 10–30 second MP4.
2. 1–2 minute MP4.
3. 5–10 minute MP4.
4. 30 minute MP4.
5. 60 minute MP4.

Do not start with a 1 GB+ 60-minute video. If the small test works but a large test fails, the issue is usually server request limits, RAM, CPU time, disk space, or free-tier limits—not the browser code.
