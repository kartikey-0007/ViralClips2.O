# ViralClip AI — New Full-Stack Starter

An independent Opus-style long-video-to-short-clips project. It is designed around a static frontend + server-side FFmpeg backend so it does not depend on SharedArrayBuffer or browser FFmpeg.

## What works
- Large video upload using 8 MB resumable-style chunks
- MP4 / MOV / WebM / MKV / M4V / AVI
- 30–60 minute inputs (server/storage limits still apply)
- 15 / 30 / 45 / 60 second clips
- 3 / 5 / 7 / 10 clips
- 9:16, 1:1, 16:9 output
- Smart moment selection (deterministic spread across the video)
- Evenly spaced selection
- Manual timestamps
- Server-side FFmpeg conversion
- Preview + download
- YouTube URL preview only; no YouTube audiovisual downloader

## Important: what this MVP does NOT claim
True OpusClip-level AI moment detection, transcription, animated captions, face tracking and virality scoring need a speech/AI pipeline. This starter keeps the processing reliable first. The "Smart moments" mode currently spreads clips through the video instead of pretending it has an AI model.

## Architecture
- `frontend/`: static HTML/CSS/JS. Put this on GitHub Pages.
- `backend/`: FastAPI + native FFmpeg. Put this on a server such as Render or another Docker host.

GitHub Pages is static hosting; it is not the place to run FFmpeg. GitHub documents Pages as static hosting and lists limits including a 1 GB published-site limit and 10-minute deployment timeout. See: https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits

Render currently offers free web services for testing/hobby projects, but free services sleep after 15 minutes idle and have ephemeral filesystems. Large/production video processing should use paid compute + persistent/object storage or another suitable host.

## 1) Create GitHub repo
On GitHub mobile:
1. Open GitHub → `+` → `New repository`.
2. Repository name: `ViralClip-AI`.
3. Public.
4. Create repository.
5. Upload the contents of `frontend/` to the repository root if you want GitHub Pages immediately.
6. Keep the `backend/` folder in the repo too if you want one repo for both parts.

## 2) GitHub Pages
Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/ (root)` → Save.
The frontend will be at `https://YOUR-USERNAME.github.io/ViralClip-AI/`.

## 3) Deploy backend
Recommended beginner path: Render Docker Web Service.
1. Create a Render account.
2. New → Web Service.
3. Connect your GitHub repo.
4. Root Directory: `backend`.
5. Environment: Docker.
6. Instance: Free for testing only.
7. Create Web Service.
8. Wait for the service to become Live.
9. Copy its `https://....onrender.com` URL.

## 4) Connect frontend to backend
Open `frontend/app.js` and replace:
`YOUR_BACKEND_URL`
with your Render URL, for example:
`https://your-service.onrender.com`
Commit the change. GitHub Pages will redeploy.

## 5) Test
Open the GitHub Pages site on Android Chrome.
1. Upload a small 10–30 second MP4 first.
2. Select 15 sec / 3 clips / 9:16 / Evenly spaced.
3. Generate.
4. Confirm all 3 previews play.
5. Then test a longer 5–10 minute file.
6. Only after that, test 30–60 minute files.

## 6) If you want real AI later
Add a server-side transcription + scoring pipeline (for example Whisper/faster-whisper + an LLM or a local model). Never put an AI API key in `frontend/app.js`.

## YouTube
The YouTube tab intentionally embeds a preview and does not download audiovisual files. For clipping, upload the original file you own/are authorized to use. This avoids building a YouTube downloader that conflicts with YouTube developer policies.
